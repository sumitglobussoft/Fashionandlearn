

<?php

class Membership_MembershipController extends Zend_Controller_Action {

    protected $setExpressResponse;
    protected $paymentAmount;
    protected $paymentOneTimeAmt;

    public function init() {
        
    }

    public function preDispatch() {

        // Display the recent updated profile picture  
        $user_id;
        if (isset($this->view->session->storage->user_id)) {
            $user_id = $this->view->session->storage->user_id;
            $objUsermetaModel = Application_Model_UsersMeta::getinstance();
            $getmetaresult = $objUsermetaModel->getUserMetaDetail($user_id);
            $this->view->profilepic = $getmetaresult['user_profile_pic'];
        }
        $objCategoryModel = Application_Model_Category::getInstance();
        $allCategories = $objCategoryModel->getAllCategories();
        $this->view->AllCategories = $allCategories;
    }

    public function membershipAction() {
         $objFacebookModel = Engine_Facebook_Facebookclass::getInstance();
        $url = $objFacebookModel->getLoginUrl();
        $users = Application_Model_Users::getinstance();
       
        $this->view->fbLogin = $url;
        $user_id;
        if (isset($this->view->session->storage->user_id)) {
            $user_id = $this->view->session->storage->user_id;
        }

        $objPaymentMethods = Application_Model_PaymentMethods::getinstance();
        $objUserModel = Application_Model_Users::getinstance();
        $objSubscription = Application_Model_Subscription::getInstance();
        $objPayment = Application_Model_Payment::getinstance();
        if ($this->getRequest()->isPost()) {
            $subvalue = $this->getRequest()->getPost('plan');
            $subs = $this->getRequest()->getParam('subs');
            $subid = $this->getRequest()->getParam('sub_id');
            $this->view->session->storage->subid = $subid;
            $this->view->session->storage->pid = $pid;
            $this->view->session->storage->subvalue = $subvalue;
            $valueSub = $this->getRequest()->getParam('valueSub');
            //echo $valueSub; die('123');
            //$this->_redirect("/upgrade");
        }

        if (isset($user_id)) {

            $res = $objPaymentMethods->selectPrimaryPayment($user_id);
            $this->view->result = $res;

            $selectTrialSub = $objSubscription->selectTrialSubscription();
            $selectNonTrialSub = $objSubscription->selectNonTrialSubscription();
            $this->view->trialsub = $selectTrialSub;
            $this->view->notrialsub = $selectNonTrialSub;
            $selectsubresult = $objPayment->selectSub($user_id);
            $this->view->subresult = $selectsubresult;
            //echo "<pre>"; print_r($selectsubresult); die('@@@@@@');
            //$this->view->subscription = $selectSubscription;
            $this->view->session->storage->subsresult = $selectsubresult;
            ///$notify = Application_Model_Savednotifications::getinstance();
           // $notificationresult = $notify->getNotification($user_id);

            //$this->view->session->storage->notyfyvalue = $notyfyvalue;
           // $notification_count = count($notificationresult);
//            $this->view->session->storage->notificationresult = $notificationresult;
//            $this->view->session->storage->notification_count = $notification_count;
            $paymentId;
            if (isset($this->view->session->storage->member)) {
                $paymentId = $this->view->session->storage->member['payment_id'];
            }
            if (isset($paymentId)) {
                // echo $paymentId; die('---');
                $paymentType = $objPayment->getPaymentType($paymentId);
                //print_r($paymentType); die('122');
                $premimStatus = $objUserModel->selectPremiumStatus($user_id);
                //print_r($paymentType); die('---');
                $this->view->premimStatus = $premimStatus['premium_status'];
                $this->view->paymentType = $paymentType['payment_type'];

                $this->view->session->storage->payType = $paymentType['payment_type'];
                $this->view->session->storage->premiumStatus = $premimStatus['premium_status'];
            }
        }
    }

    public function upgradeAction() {
        $user_id;
        if (isset($this->view->session->storage->user_id)) {
            $user_id = $this->view->session->storage->user_id;
        }
        $objUserModel = Application_Model_Users::getinstance();
        $objUsermetaModel = Application_Model_UsersMeta::getinstance();
        $objSubscription = Application_Model_Subscription::getInstance();
        $objPayment = Application_Model_Payment::getinstance();
        $selectTrialSub = $objSubscription->selectTrialSubscription();
        $selectNonTrialSub = $objSubscription->selectNonTrialSubscription();
        $payResult = $objPayment->selectMemberships($user_id);
        $this->view->payResult = $payResult;
        $this->view->trialsub = $selectTrialSub;
        $this->view->notrialsub = $selectNonTrialSub;
        $valueSub;
        if (isset($this->view->session->storage->valueSubBox)) {
            $valueSub = $this->view->session->storage->valueSubBox;
            $this->view->valueSubBox = $valueSub;
        }
        $objPaymentMethods = Application_Model_PaymentMethods::getinstance();
        $primaryCard = $objPaymentMethods->selectPrimaryPayment($user_id);
        $this->view->primaryCard = $primaryCard;
        if ($this->_request->isXmlHttpRequest()) {
            $this->_helper->viewRenderer->setNoRender(true);
            $this->_helper->layout()->disableLayout();
            $reactive = $this->getRequest()->getPost('id');
            if ($reactive) {
                $data = array('premium_status' => 1);
                $updateStatus = $objUserModel->updatePremiumStatus($data, $user_id);
                if ($updateStatus) {
                    echo json_encode($updateStatus);
                }
            }
        }
        $Date = date("y-m-d");
        $nextPeriod = date('Y-m-d', strtotime($Date . ' + 14 day'));
        $dateVal = explode('-', $nextPeriod);

        switch ($dateVal[1]) {
            case "01":
                $m = "January";
                break;
            case "02":
                $m = "February";
                break;
            case "03":
                $m = "March";
                break;
            case "04":
                $m = "April";
                break;
            case "05":
                $m = "May";
                break;
            case "06":
                $m = "June";
                break;
            case "07":
                $m = "July";
                break;
            case "08":
                $m = "August";
                break;
            case "09":
                $m = "September";
                break;
            case "10":
                $m = "October";
                break;
            case "11":
                $m = "November";
                break;
            case "12":
                $m = "December";
                break;
            default:
                break;
        }
        $this->view->year = $dateVal[0];
        $this->view->month = $m;
        $this->view->date = $dateVal[2];
    }

    public function membershipAjaxHandlerAction() {

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        if ($this->getRequest()->isPost()) {
            $subid = $this->getRequest()->getParam('sub_id');
            $planid = $this->getRequest()->getParam('plan_id');
            $subvalue = $this->getRequest()->getParam('select');
            $valueSub = $this->getRequest()->getParam('valueSub');
            //echo $valueSub; die('123');
            unset($this->view->session->storage->subid);
            $this->view->session->storage->subid = $subid;
            unset($this->view->session->storage->pid);
            $this->view->session->storage->pid = $planid;
            unset($this->view->session->storage->subvalue);
            $this->view->session->storage->subvalue = $subvalue;
            if (isset($valueSub)) {
                $this->view->session->storage->valueSubBox = $valueSub;
            }
            echo json_encode($subid);
        }
    }

    public function upgradeMembershipAjaxHandlerAction() {

        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();

        if ($this->getRequest()->isPost()) {

            $subsid = $this->getRequest()->getParam('subsc_id');
            $planidval = $this->getRequest()->getParam('plan_id_val');
            $subscvalue = $this->getRequest()->getParam('selected_val');
            print_r();
            $this->view->session->storage->pid = $planidval;
            $this->view->session->storage->subid = $subsid;
            $this->view->session->storage->subvalue = $subscvalue;
//           echo json_encode("1"); 
        }
    }

    public function cancelAjaxHandlerAction() {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout()->disableLayout();
        //$subid = $this->getRequest()->getParam('method');
        $objPagar = new Engine_Pagarme_PagarmeClass();
        $objPayment = Application_Model_Payment::getinstance();
        $pagarSubId;
        $paymentid;
        if (isset($this->view->session->storage->member)) {
            $pagarSubId = $this->view->session->storage->member['pagar_subscription_id'];
            $paymentid = $this->view->session->storage->member['payment_id'];
        }
        //$this->session->storage->member =1;
        Pagarme :: setApiKey("ak_test_H8XElSFHXeO5BChZnfGbLyS3CdYvMU");
        $subscription = PagarMe_Subscription :: findById($pagarSubId);
        $subscription->cancel();  // Cancel
        $status = $subscription->getStatus();
        if ($status) {
            $data = array('status' => $status);
            $updtaeStatus = $objPayment->updateStatus($data, $paymentid);
        }
        echo $status; die('123');
        if ($updtaeStatus) {
            $this->view->session->storage->member = $updtaeStatus;
        }
        echo json_encode($status);
    }

}
?>
