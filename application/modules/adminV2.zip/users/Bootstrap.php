<?php
class Users_Bootstrap extends Zend_Application_Module_Bootstrap {

}