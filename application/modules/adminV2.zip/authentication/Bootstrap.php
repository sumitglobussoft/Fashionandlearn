<?php
class Authentication_Bootstrap extends Zend_Application_Module_Bootstrap {



}