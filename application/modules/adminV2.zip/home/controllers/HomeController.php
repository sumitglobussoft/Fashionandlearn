<?php

/**
 * AdminController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Home_HomeController extends Zend_Controller_Action {

    public function init() {
        
    }

    public function preDispatch() {
        $request = new Zend_Controller_Request_Http();
        

        //set cookie for unique visitor count
        //setcookie('cookieName', 'value', 'lifetime', 'path', 'domain'); 
        if ($request->getCookie('fashioncount')==null) {
            setcookie("fashioncount", 0, time() + (86400 * 30), "/");
            $objss = Application_Model_Sitestatistics::getInstance();
           $objss->insertstatistics("visit");
           
        }
        $objCategoryModel = Application_Model_Category::getInstance();
        $allCategories = $objCategoryModel->getAllCategories();
        $this->view->AllCategories = $allCategories;
    }

    public function homeAction() {

        if ($this->view->auth->hasIdentity()) {
            $this->_redirect('/dashboard');
        }
        //dev:priyanka varanasi
        //dev: to get facebook login url
        $objFacebookModel = Engine_Facebook_Facebookclass::getInstance();
        $url = $objFacebookModel->getLoginUrl();
        $this->view->fbLogin = $url;

        //For showing all Classes in Home-page
        $objAllClasses = Application_Model_TeachingClasses::getInstance();
        $classResult = $objAllClasses->getAllCLasses();
        $this->view->classes = $classResult;
//        echo "<pre>";print_r($classResult);die;
//        
//        
        //////priyanka varanasi
        //To show the trending classes in home page 
        $objMetaModel = Application_Model_UsersMeta::getinstance();
        $objUserModel = Application_Model_Users::getinstance();
        $objClassReview = Application_Model_ClassReview::getinstance();
        $teachingclass = Application_Model_TeachingClasses::getinstance();
        $teachingvideoclass = Application_Model_TeachingClassVideo::getinstance();
        $trending = $teachingclass->gettrendingclasses();


        if ($trending) {
            foreach ($trending as $key => $row) {
                $value[$key] = $row['stud_count'];
            }
            array_multisort($value, SORT_DESC, $trending);

            $count = 0;
            foreach ($trending as $val) {
                $allreview = $objClassReview->getAllReview($val['class_id']);

                $calculatereview = $objClassReview->getCalculateReview($val['class_id']);

                if (count($allreview) != 0) {
                    $classreviewpercentage = round((count($calculatereview) / count($allreview)) * 100);
                } else {
                    $classreviewpercentage = 0;
                }
                $trending[$count]['review_per'] = $classreviewpercentage;
                $count++;
            }
            foreach ($trending as $key => $value) {
                $funnyarray = $teachingvideoclass->getterndingclassvideos($value['class_id']);

                if ($funnyarray) {
                    foreach ($funnyarray as $value) {
                        $trending[$key]['class_video_title'] = $value['class_video_title'];
                        $trending[$key]['class_video_url'] = $value['class_video_url'];
                        $trending[$key]['class_video_id'] = $value['class_video_id'];
                        $trending[$key]['video_id'] = $value['video_id'];
                        $trending[$key]['cover_image'] = $value['cover_image'];
                        $trending[$key]['video_thumb_url'] = $value['video_thumb_url'];
                    }
                }
            }

//            echo"<pre>";print_r($trending);echo"</pre>"; die;

            $this->view->trending = $trending;
        }


        //For showing all Projects in Home-Page
        $teach = Application_Model_Projects::getinstance();
        $objClassProjectLikes = Application_Model_ProjectLikes::getinstance();
        $objProjectComments = Application_Model_ProjectComments::getinstance();
        $result = $teach->getallprojects();
        $recentprojects = $teach->mostrecentProjects();
        $mostlikeprojects = $teach->mostlikeProjects();

        if ($result) {
            $i = 0;
            foreach ($result as $val) {

                $project_id = $val['project_id'];
                $resultlike = $objClassProjectLikes->getprojectlikes($project_id);
                $commentCount = $objProjectComments->getComments($project_id);
                if (isset($this->view->session->storage->user_id)) {
                    $userid = $this->view->session->storage->user_id;
                    $this->view->user_id = $userid;
                    $userresultlike = $objClassProjectLikes->getuserprojectlikes($userid, $project_id);
                    if ($userresultlike) {
                        $result[$i]['islike'] = 1;
                    } else {
                        $result[$i]['islike'] = 0;
                    }
                }
                $result[$i]['discussslikecount'] = @$resultlike;
                $result[$i]['comment_count'] = @count($commentCount);
                $i++;
            }
        }
//        echo "<pre>";print_r($result);die();
        $this->view->projects = $result;
//        $this->view->recent = $recentprojects;
    }

}
