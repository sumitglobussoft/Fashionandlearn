<?php

/**
 * PaymentdetailsController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Admin_PaymentdetailsController extends Zend_Controller_Action {

    public function init() {
        
    }

    public function preDispatch() {
        $objuserperminssion = Application_Model_Sitesettings::getInstance();
        $resultperminssion = $objuserperminssion->permissionstatus();
        $this->view->classpermissions = $resultperminssion['0'];
    }

    public function paymentDetailsAction() {

        $objpayment = Admin_Model_Payment::getInstance();
        $paymentdetails = $objpayment->getPaymentDetails();

        //echo "<pre>";print_r($paymentdetails);die;
        $this->view->paymentdetails = $paymentdetails;
    }

    public function getPaidStudentsAction() {


        $payment = Admin_Model_Payment::getInstance();
        $teachingclass = Admin_Model_TeachingClasses::getInstance();
        $teachersstudents = Admin_Model_Classenroll::getInstance();
        $uservideostatus = Admin_Model_UserVideoStatus::getInstance();
        $classreviewscount = Admin_Model_ClassesReview::getInstance();
        $paymentdata = Admin_Model_paymentdata::getInstance();

        $getpercentage = $paymentdata->getpercentage();
//        echo '<pre>';        print_r($getpercentage); die;
        $this->view->getpercentage = $getpercentage;

        $projects = Admin_Model_Projects::getInstance();
        $result = $payment->getPaidStudents();
        $percentage = $this->getRequest()->getPost('percenrage');
        $method = $this->getRequest()->getPost('method');
        $percentage = trim($percentage, "%");



        if ($this->getRequest()->isXmlHttpRequest()) {

            if ($method == 'devide_per') {
                $data = array('devide_percentage' => $percentage);
                $where = array('data', 1);
                $paymentdata->updatepercentagedata($data, $where);
            } else if ($method == 'st_per') {
                $data1 = array('students_per' => $percentage);
                $where = array('data', 1);

                $paymentdata->updateavgstudents($data1, $where);
            } else if ($method == 'pr_per') {
                $data2 = array('proj_per' => $percentage);
                $where = array('data', 1);

                $paymentdata->updateprojects($data2, $where);
            } else if ($method == 'video_per') {
                $data3 = array('videoview_per' => $percentage);
                $where = array('data', 1);

                $paymentdata->updatevideoesviews($data3, $where);
            }
        }

        $yearlystudentcount = 0;
        $monthlystudentcount = 0;
//        echo '<pre>';  print_r($result); die;
        foreach ($result as $key => $value) {
            if ($value['subscription_id'] == 4 || $value['subscription_id'] == 5) {

                $yearlyamount = $value['payment_amount'];
                $yearlystudentcount++;
            }
            if ($value['subscription_id'] == 1 || $value['subscription_id'] == 3) {
                $monthlyamount = $value['payment_amount'];
                $monthlystudentcount++;
            }
        }
//        print_r($monthlystudentcount); die;
        $totalstudents = $yearlystudentcount + $monthlystudentcount;
//        print_r($totalstudents); die;
//        $totalstudents=  count($result); 
//        print_r($totalstudents); die;
        $this->view->totalstudents = $totalstudents;
//        $avergaesubscription = (($yearlyamount * $yearlystudentcount) + ($monthlyamount * $monthlystudentcount)) / $totalstudents;
        $totalassets = 35 * $totalstudents;
        $this->view->totalassets = $totalassets;
//        print_r($totalassets); 
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);
            if ($percentage) {
                $teachershare = ($totalassets * $percentage) / 100;
                $this->view->teachershare = $teachershare;
//            return $teachershare;
                echo $teachershare;
            }
        }
        $teachershare = ($totalassets * $getpercentage['devide_percentage']) / 100;
        $this->view->teachershare = $teachershare;
        /* -----------------Teacher Salary Distribution----------------------- */


        $teacherdetails = $teachingclass->getTeachersDetails();


        $count = 0;
        $i = 0;
        $j = 0;
        $k = 0;
        $x = 0;
        $totalleftover = 0;
        foreach ($teacherdetails as $key => $value) {

            $teacher_name = $value['first_name'];

            $teacher_id = $value['user_id'];
            $getSeenVideoCount = $uservideostatus->getSeenVideoCount($teacher_id);
            $getreviewcount = $classreviewscount->getSatisfactionPercentage($teacher_id);
            //dev: priyanka varanasi
            ////modified these line as the project count and students count giving ny the above query is wrong
            //desc: to get user projects

            $projcount = $projects->getProjectCount($value['user_id']);


            //to get user students (students enrolled)
            $studentcount = $teachersstudents->getClasEnrollCount($value['user_id']);
            if (!empty($studentcount)) {
                $teacherdetails[$count]['studentcount'] = $studentcount;
            } else {
                $teacherdetails[$count]['studentcount'] = 0;
            }
            if (!empty($projcount)) {

                $teacherdetails[$count]['projectcount'] = $projcount;
            } else {
                $teacherdetails[$count]['projectcount'] = 0;
            }
            //////////code ends///////////////////
            $teacherdetails[$count]['videoseencount'] = $getSeenVideoCount['video seen count'];
            $teacherdetails[$count]['reviewpercent'] = $getreviewcount;
            $teacherdetails[$count]['reviewpercent'] = $getreviewcount;
            $i+= $value['class count'];

            //priyanka added two lines
            $j+= $teacherdetails[$count]['projectcount'];
            $k+= $teacherdetails[$count]['studentcount'];
            //-----code ends------------//
            //commented these lines
            // $j+= $value['studentcount'];
            //$k+= $value['projectcount'];

            $x+= $teacherdetails[$count]['videoseencount'];

            $count++;
        }

        $this->view->i = $i;
        $this->view->j = $j;
        $this->view->k = $k;
        $this->view->x = $x;
        $this->view->teacherdetails = $teacherdetails;
//        print_r($teacherdetails);die;



        $nr_st = $i;

        $finalresult = array();
        $paymentuser = array();
        $countarr = 0;
        $totalpays = 0;

        foreach ($teacherdetails as $key => $value) {


            $satisfaction_per = $value['reviewpercent'];
            if ($satisfaction_per >= 90) {
                $satisfaction_per = 100;
            } else if ($satisfaction_per >= 80) {

                $satisfaction_per = 95;
            } else if ($satisfaction_per >= 70) {
                $satisfaction_per = 90;
            } else {
                $satisfaction_per = 85;
            }
//	  $total_value=round(($value['studentcount']/($i))*20)+round(($value['projectcount']/($i))*20)+round(($value['videoseencount']/($i))*70);


            $finalresult[$countarr]['first_name'] = $value['first_name'];
            $finalresult[$countarr]['user_id'] = $value['user_id'];
            $finalresult[$countarr]['payment_status'] = $value['teacher_payment_status'];
            $paymentuser[$countarr]['email'] = $value['paypal_email'];
            $finalresult[$countarr]['paypal_email'] = $value['paypal_email'];

            $finalresult[$countarr]['class count'] = $value['class count'];
            $finalresult[$countarr]['studentcount'] = $value['studentcount'];
            $finalresult[$countarr]['projectcount'] = $value['projectcount'];
            $finalresult[$countarr]['videoseencount'] = $value['videoseencount'];
            $finalresult[$countarr]['satisfaction_per'] = $value['reviewpercent'];
            @ $finalresult[$countarr]['studentcount_per'] = ($value['studentcount'] / ($j)) * $getpercentage['students_per'];
            @ $finalresult[$countarr]['projectcount_per'] = ($value['projectcount'] / ($k)) * $getpercentage['proj_per'];
            $finalresult[$countarr]['videoseencount_per'] = ($value['videoseencount'] / ($x) * $getpercentage['videoview_per']);
            $total_value = $finalresult[$countarr]['studentcount_per'] + $finalresult[$countarr]['projectcount_per'] + $finalresult[$countarr]['videoseencount_per'];
            $finalresult[$countarr]['total_value'] = $total_value;
            $finalresult[$countarr]['commission_without_sat'] = (($teachershare) * $total_value) / 100;
            $finalresult[$countarr]['commission_with_sat'] = ($finalresult[$countarr]['commission_without_sat'] * $satisfaction_per) / 100;
            $paymentuser[$countarr]['amount'] = $finalresult[$countarr]['commission_with_sat'];
            $finalresult[$countarr]['left_over'] = $finalresult[$countarr]['commission_without_sat'] - $finalresult[$countarr]['commission_with_sat'];
            $totalleftover = $totalleftover + $finalresult[$countarr]['left_over'];
            $totalpays = $totalpays + $finalresult[$countarr]['commission_with_sat'];

            /*             * abhishekm
             * inserting commission of teacher in user table
             */
            $commission = Application_Model_Users::getInstance();
            $success = $commission->updatecommission($finalresult[$countarr]['commission_with_sat'], $value['user_id']);

            $countarr++;
        }

        $admindata = Admin_Model_AdminData::getInstance();
        $data = array('studentpay' => $totalpays);
        $result = $admindata->insertAdmindata($data);
        //echo"<pre>";print_r($finalresult);die;
//        $this->view->session->storage->finalresult=$finalresult;
        $this->view->finalresult = $finalresult;

        $this->view->session->storage->paymentuser = $paymentuser;
    }

    public function paymentTeacherAction() {
        $payment = Admin_Model_Payment::getInstance();
        $adminpaymentmonthly = Admin_Model_AdminPaymentMonthly::getInstance();
        $teachingclasses = Admin_Model_TeachingClasses::getInstance();
        $teacherpaymentdetails = Admin_Model_Teacherpaymentdetails::getInstance();
        $paymentdata = Admin_Model_paymentdata::getInstance();
        $monthlyleftover = $this->getRequest()->getPost('monthlyleftover');
        $checkarruser = $this->getRequest()->getPost('checkarruser');
        $total_teacher = $teachingclasses->totalTeacher();
        $totalClasses = $teachingclasses->totalClasses();

        $result = $payment->getPaidStudents();
        $yearlystudentcount = 0;
        $monthlystudentcount = 0;
        $yearlyamount = 0;
        $monthlyamount = 0;
        $currentMonth = date('Y-m');
        
        $c = date('Y-m-d',strtotime($currentMonth.'-15'));
        $p = date('Y-m-d', strtotime($c.'-1 month'));

        $date = date("Y/m/d");
        $date = explode('/', $date);
        $year = $date[0];
        $curdate = (int) $date[2];

        if ($curdate < 15) {
            $month = $date[1] - 1;
        } else {

            $month = $date[1];
        }
     
             
        foreach ($result as $key => $value) {
            if ($value['subscription_id'] == 4 || $value['subscription_id'] == 5) {
            
                $yearlyamount = $value['payment_amount'];
                $yearlystudentcount++;
            }
            if ($value['subscription_id'] == 1 || $value['subscription_id'] == 3) {
                $monthlyamount = $value['payment_amount'];
                $monthlystudentcount++;
            }
        }
        $monthly_total_amount = $monthlystudentcount * $monthlyamount;

        $total_yearly_payment = $yearlystudentcount * $yearlyamount;


        $getpercentage = $paymentdata->getpercentage();
        $monthly = $total_yearly_payment / 12;
        $total_assets = $monthly_total_amount + $monthly;
        $teacher_patternship = ($total_assets * $getpercentage['devide_percentage']) / 100;
        $this_month = $monthly + $monthly_total_amount;
        $data = array('Month' => $month, 'monthlyleftover' => $monthlyleftover, 'no_of_class' => $totalClasses, 'no_of_teacher' => $total_teacher, 'annual_earned' => $total_yearly_payment, 'monthly_earned' => $monthly_total_amount, 'Total_subscibe_monthly' => $monthlystudentcount, 'Total_subscribe_Annually' => $yearlystudentcount, 'Teacher_patternship' => $teacher_patternship, 'devided_by_12' => $monthly, 'Year' => $year, 'Total' => $this_month);

        $adminpaymentmonthly->insertmonthlyDetails($data,$month,$year);
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        if ($this->getRequest()->isPost()) {
            $checkarr = $this->getRequest()->getPost('checkarr');

            $objPaypal = Engine_Payment_Paypal_Paypal::getInstance();
            $massPay = $objPaypal->MassPay($checkarr);

            if ($massPay['ACK'] == "Success") {

// 
                foreach ($checkarruser as $monthlypaymentdata) {
                  
                    $systemdate1 = date("Y/m/d");

                    $systemdate = split('/', $systemdate1);
                    $year = $systemdate[0];
                    if($systemdate[2]<=15){
                    $month = $systemdate[1] - 1;}
                    else{
                        $month = $systemdate[1];
                    }
                    $teacher_id = $monthlypaymentdata['userid'];
                    $amount = $monthlypaymentdata['amount'];
                    $teacher_monthly_paymentdata = array('paid_status' =>'paid','date_of_payment'=>$systemdate1,);
                    
                    $teacherpaymentdetails->updatepaymentstatus($teacher_monthly_paymentdata,$teacher_id);
                }

                $objUserMeta = Admin_Model_UsersMeta::getInstance();
                foreach ($checkarruser as $val) {
                    $resultusers = $objUserMeta->updatePaymentUsermeta($val['userid']);
                }
                echo json_encode($massPay['ACK']);
            } else {
                echo json_encode($massPay['L_LONGMESSAGE0']);
            }
        }
    }

    /* Developer:Rakesh Jha
      Dated:13-03-15
      Description:Teacher Payment through referal
     */

    public function referalPaymentAction() {
        $users = Application_Model_Users::getInstance();
        $result = $users->getReferedStudents();
        if ($result) {
            $count = 0;
            foreach ($result as $key => $value) {
                $result1 = $users->getReferStudents();
//             $result2=$users->getReferalStudents();
                $monthly = $result1['monthly_user'];

//          $yearly=$result2['yearly_user'];
                $totaluser = $value['total_user'];
                $year = ($totaluser - $monthly);
                $result[$count]['monthly_user'] = $monthly;
                $result[$count]['yearly'] = $year;
                $amount = ($year * 25 + $monthly * 10);
                $result[$count]['amount'] = $amount;
                $name = $users->getTeachername($value['user_id']);
                $result[$count]['name'] = $name['first_name'];
                $count++;
            }
            $this->view->result = $result;
        }
    }

}
