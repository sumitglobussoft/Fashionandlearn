<?php

/**
 * ManageusersController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Admin_ManageusersController extends Zend_Controller_Action {

    public function init() {
        
    }

    public function preDispatch(){
       $objuserperminssion = Application_Model_Sitesettings::getInstance();
        $resultperminssion = $objuserperminssion->permissionstatus();
        $this->view->classpermissions = $resultperminssion['0'];
    }
    //dev:priyanka varanasi
    //desc: To show  user details in admin panel
    public function manageusersAction() {
        $objUserModel = Admin_Model_Users::getInstance();
        $userDetails = $objUserModel->getUsersDetails();
         $objPaymentsModel = Admin_Model_Payment::getInstance();
         $result = $objPaymentsModel->getpaymembershipusers();
         if($result){
          $this->view->memberships = $result;    
         }
        if($userDetails){
     $this->view->users = $userDetails;
    }
    }
    //dev:priyanka varanasi
    //desc: To deactivate users
    
    public function userAjaxHandlerAction() {
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $objUserModel = Admin_Model_Users::getInstance();
        $objPaymentsModel = Admin_Model_Payment::getInstance();
        $objstatistics = Application_Model_Sitesettings::getInstance();
        if ($this->getRequest()->isPost()) {
            $method = $this->getRequest()->getParam('method');

            switch ($method) {
                case 'useractive':
                    $userstate = $this->getRequest()->getParam('userid');
                    $ok = $objUserModel->getstatustodeactivate($userstate);

                    if ($ok) {
                        echo $userstate;
                        return $userstate;
                    } else {
                        echo "Error";
                    }
                    break;
                case 'userdelete':
                    $userid = $this->getRequest()->getParam('userid');
                    $result = $objUserModel->userdelete($userid);
                    if ($result) {
                        echo $result;
                        return $result;
                    } else {
                        echo "error";
                    }
                    break;
                  case 'userperminssion':
                   
                   $result = $objstatistics->updastatistics();
                    if ($result) {
                       print_r($result);die();
                    } else {
                        echo "error";die();
                    }
                    break;
//                case 'ALL':
//                    $userDetails = $objUserModel->getUsersDetails();
//                    if ($userDetails) {
//                        echo json_encode($userDetails);
//                    }
//                    break;
//                case 'Membership':
//                    $result = $objPaymentsModel->getpaymembershipusers();
//                    if ($result) {
//                        echo json_encode($result);
//                    }
//                    break;
            }
        }
    }

    //dev:priyanka varanasi
    //desc: To edit user
    public function editUserAction() {
        
        $objUserModel = Admin_Model_Users::getInstance();
        $objUsermetaModel = Admin_Model_UsersMeta::getInstance();
        $userID = $this->getRequest()->getParam('uid');
        
        if ($this->getRequest()->isPost()) {
           
            $imageName = $_FILES["fileToUpload"]["name"];
            $imageTmpLoc = $_FILES["fileToUpload"]["tmp_name"];
            $userdata['first_name'] = $this->getRequest()->getPost('firstname');
            $userdata['last_name'] = $this->getRequest()->getPost('lastname');
            $userdata['email'] = $this->getRequest()->getPost('email');
            $userdata['password'] = $this->getRequest()->getPost('password');


            $ext = pathinfo($imageName, PATHINFO_EXTENSION);
            $imageNamePath = $imageName;

            if (!empty($imageName)) {


                if ($ext != "jpg" && $ext != "png" && $ext != "jpeg" && $ext != "gif") {

                    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    $ext = 0;
                } else {
                    // Path and file name
                    $imagepathAndName = "profileimages/$userID/" . $imageNamePath;
                    if($imagepathAndName){
                    $imagemoveResult = (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $imagepathAndName));
                    $imagepathAndName = "/profileimages/$userID/" . $imageNamePath;
                    $data1 = array('user_profile_pic' => $imagepathAndName
                    );
                    $editResultumeta = $objUsermetaModel->editUsermeta($data1, $userID);
                    $check = $objUserModel->updateUserDetails($userID, $userdata);
                    if ($check || $editResultumeta) {
                     $this->view->message = "Data Edited succesfully";
                   }
                    }
                    }
                
            } else {

                $result = $objUsermetaModel->getuserprofilepic($userID);

                ;
                $data1 = array('user_profile_pic' => $result['user_profile_pic']
                );

                $editResultumeta = $objUsermetaModel->editUsermeta($data1, $userID);

                $check = $objUserModel->updateUserDetails($userID, $userdata);

                if ($check || $editResultumeta) {
                    $this->view->message = "Data Edited succesfully";
                }
            }
        }
        $user = $objUserModel->getUsersDeatilsByID($userID);
        $this->view->user = $user;
    }

    //dev:priyanka varanasi
    //desc: To create user
    public function createUserAction() {
        
        $objUserModel = Admin_Model_Users::getInstance();
        $objUsermetaModel = Admin_Model_UsersMeta::getInstance();

        if ($this->getRequest()->isPost()) {
            $firstname = $this->getRequest()->getPost('firstname');
            $lastname = $this->getRequest()->getPost('lastname');
            $email = $this->getRequest()->getPost('email');
            $password = $this->getRequest()->getPost('password');
            $gender = $this->getRequest()->getPost('gender');
            $city = $this->getRequest()->getPost('city');
            $zip = $this->getRequest()->getPost('zip');
            $imageName = $_FILES["fileToUpload"]["name"];
            $imageTmpLoc = $_FILES["fileToUpload"]["tmp_name"];

            if (isset($firstname) && isset($lastname) && isset($email) && isset($password)) {

                $data = array('first_name' => $firstname,
                    'last_name' => $lastname,
                    'password' => $password,
                    'email' => $email,
                    'status' => '0',
                    'reg_date'=>date('Y-m-d'),
                    'role' => '1',
                );
              
                $insertionResult = $objUserModel->insertUser($data);
               
               
                $ext = pathinfo($imageName, PATHINFO_EXTENSION);
                $imageNamePath = $imageName;
                $target_dir = "/profileimages/$insertionResult";
                $location = getcwd() . $target_dir;
                @mkdir($location, 0777, true);
                
                if ($imageName) {

                    if ($ext != "jpg" && $ext != "png" && $ext != "jpeg" && $ext != "gif") {

                        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                        $ext = 0;
                    } else {
                        // Path and file name
                        $imagepathAndName = "profileimages/$insertionResult/" . $imageNamePath;

                        $imagemoveResult = (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $imagepathAndName));
                        
                        
                        $imagepathAndName = "/profileimages/$insertionResult/" . $imageNamePath;
                    }
                }
                if ($insertionResult) {
                    $metaData = array('user_id' => $insertionResult,
                        'user_profile_pic' => $imagepathAndName,
                        'city' => $city,
                        'zip' => $zip);
                    //$notifydata = array('user_id' => $insertionResult);

                    $result = $objUsermetaModel->insertUsermeta($metaData);
               
                    if ($result) {
                        $this->_redirect('/admin/manageusers');
                    }
                }
            }
        }
    }

}
