<?php

/* require "pagarme-php/Pagarme.php"; */

/**
 * MembershipplansController
 *
 * Dev: Namrata Singh
 * Date: 28-feb-2015
 */
class Admin_MembershipplansController extends Zend_Controller_Action {

    public function init() {
        
    }
    public function preDispatch(){
       $objuserperminssion = Application_Model_Sitesettings::getInstance();
        $resultperminssion = $objuserperminssion->permissionstatus();
        $this->view->classpermissions = $resultperminssion['0'];
    }

    public function membershipPlansAction() {
        $subModel = Admin_Model_Subscription::getInstance();
        $subResult = $subModel->selectSubscription();
        $this->view->subResult = $subResult;
        //echo "<pre>"; print_r($subResult); die('123');
    }

    /* public function editPlansAction(){

      $subModel = Admin_Model_Subscription::getInstance();
      $subID = $this->getRequest()->getParam('sid');
      $selectSub = $subModel->selectSubscriptionOnId($subID);
      // echo "<pre>"; print_r($selectSub); die('123');
      $this->view->selectSub = $selectSub;
      if ($this->getRequest()->isPost()) {
      $subdata['subscription_type'] = $this->getRequest()->getPost('plantype');
      $subdata['payment_amount'] = $this->getRequest()->getPost('amount');
      $subdata['billing_period'] = $this->getRequest()->getPost('duration');
      $updateSubResult = $subModel->updateSubscription($subID,$subdata);
      if ($updateSubResult) {
      $this->_redirect('/admin/membershipplans');
      }
      }
      $selectSub = $subModel->selectSubscriptionOnId($subID);
      // echo "<pre>"; print_r($selectSub); die('123');
      $this->view->selectSub = $selectSub;
      } */

    public function createPlansAction() {
        $subModel = Admin_Model_Subscription::getInstance();
        /* require ( "pagarme-php / Pagarme.php" ); */
        $objPagar = new Engine_Pagarme_PagarmeClass();
        if ($this->getRequest()->isPost()) {
            $planname = $this->getRequest()->getPost('planname');
            $amount = $this->getRequest()->getPost('amount');
           
            $duration = $this->getRequest()->getPost('duration');
            $trial = $this->getRequest()->getPost('trial');
            if($duration > 30)
            {
                $paymenttype = 2;
            }else{
                $paymenttype = 1;
            }
           // $amountsent = (int) $amount * 100;
           
           
            Pagarme :: setApiKey("ak_test_H8XElSFHXeO5BChZnfGbLyS3CdYvMU");

            if ($trial == 0) {

                $Plan = new PagarMe_Plan(array(
                            'amount' => $amount,
                            'days' => $duration,
                            'name' => $planname
                        ));
            } else {
                $Plan = new PagarMe_Plan(array(
                            'amount' => $amount,
                            'days' => $duration,
                            'name' => $planname,
                            'trial_days' => $trial
                        ));
            }

            $Plan->create();
            //echo "<pre>"; print_r($Plan); die('-----');
            $pid = $Plan->id;
           $amount_R = $amount/100;
            if ($trial == 0) {

                $insertdata = array('subscription_type' => $planname,
                    'billing_period' => $duration,
                    'payment_amount' => $amount_R,
                    'plan_id' => $pid,
                    'trial_billing_period' => $trial,
                    'description' => 0,
                    'payment_type' => $paymenttype
                );

                $insertSub = $subModel->insertSubscriptionPlan($insertdata);
            } else {

                $insertdata = array('subscription_type' => $planname,
                    'billing_period' => $duration,
                    'payment_amount' => $amount_R,
                    'plan_id' => $pid,
                    'trial_billing_period' => $trial,
                    'description' => 1,
                    'payment_type' => $paymenttype
                );

                $insertSub = $subModel->insertSubscriptionPlan($insertdata);
            }

            if ($insertSub) {
             
                $this->_redirect("/admin/membership-plans");
            }
        }
    }

// Dev: Priyanka V
    public function membershipAjaxHandlerAction() {

        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        $subModel = Admin_Model_Subscription::getInstance();
        $subid = $this->getRequest()->getParam('delsubscripton');
        $res = $subModel->subdelete($subid);
        if ($res) {
            echo $res;
            return $res;
        } else {
            echo "error";
        }
    }

}