<?php

/**
 * AdminController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Admin_PaymentController extends Zend_Controller_Action {

    public function init() {
        
    }

    public function preDispatch() {
        $objuserperminssion = Application_Model_Sitesettings::getInstance();
        $resultperminssion = $objuserperminssion->permissionstatus();
        $this->view->classpermissions = $resultperminssion['0'];
    }

    /**
     * Developer : Bhojraj Rawte
     * Date : 19/03/2014
     * Description : Get Payment details
     */
    public function paymentDetailsAction() {
        $objWithdrawalModel = Admin_Model_WithdrawalRequest::getInstance();
        $withdrawalDetails = $objWithdrawalModel->getPaymentDeatils();
        if ($withdrawalDetails) :
            $this->view->withdrawal = $withdrawalDetails;
        endif;
    }

    /**
     * Developer : Bhojraj Rawte
     * Date : 19/03/2014
     * Description : Get Payment Approval details
     */
    public function paymentApprovalAction() {
        $objWithdrawalModel = Admin_Model_WithdrawalRequest::getInstance();
        $withdrawalDetails = $objWithdrawalModel->getPanddingPaymentDeatils();
        if ($withdrawalDetails) :
            $this->view->withdrawal = $withdrawalDetails;
        endif;
    }

    /**
     * Developer : Ramanjineyulu G
     * Date : 01/07/2014
     * Description : Get All Withdrawal details
     */
    public function withdrawalDetailsAction() {
//        $objWithdrawalDetails = Admin_Model_WithdrawalRequest::getInstance();
//        $details=$objWithdrawalDetails->getAllDeatils();
////         echo "<pre>"; print_r($details); echo "</pre>"; die;
//        
//        if ($details){
//            $this->view->allDetails = $details;
//    }
        $objWithdrawalModel = Admin_Model_WithdrawalRequest::getInstance();
        $withdrawalDetails = $objWithdrawalModel->getWithdrawalPaymentDeatils();
        if ($withdrawalDetails) :
            $this->view->withdrawal = $withdrawalDetails;
        endif;
    }

    /**
     * Developer : Bhojraj Rawte
     * Date : 06/08/2014
     * Description : Get depositor details
     */
    public function depositorDetailsAction() {
        $objUserTransactionsModel = Admin_Model_UserTransactions::getInstance();
        $transactionDetails = $objUserTransactionsModel->getdepositorDeatils();
        //echo "<pre>"; print_r($transactionDetails); echo "</pre>"; die;
        if ($transactionDetails) :
            $this->view->transaction = $transactionDetails;
        endif;
    }

    /**
     * Developer : Bhojraj Rawte
     * Date : 03/11/2014
     * Description : Get Profit details
     */
    public function profitStatsAction() {

        $objProfitModel = Admin_Model_Profit::getInstance();
        $currentProfitYear = date("Y");
        if ($this->getRequest()->getParam('profit')) {
            $currentProfitYear = $this->getRequest()->getParam('profit');
        }
        $profitStatics = $objProfitModel->adminProfitStatics($currentProfitYear);
        $month = date("m");
        if ($this->getRequest()->getParam('monthprofit')) {
            $currentProfitYear = $this->getRequest()->getParam('monthprofit');
            $month = $this->getRequest()->getParam('mo');
        }
        $profitData = $objProfitModel->getProfitStaticsByMonth($currentProfitYear, $month);
        $this->view->profityear = $currentProfitYear;
        $this->view->profitstatic = $profitStatics;
        $this->view->profitmonth = $month;
        $this->view->profitMonthstatic = $profitData;
    }

    //dev:priyanka varanasi
    //date:20/11/2014
    //desc:to get the transaction details
    public function transactionDetailsAction() {
        $objUserTransactionsModel = Admin_Model_UserTransactions::getInstance();
        $transactionDetails = $objUserTransactionsModel->gettransdetails();
        //echo "<pre>"; print_r($transactionDetails); echo "</pre>"; die;
        if ($transactionDetails) {
            $this->view->transaction = $transactionDetails;
        }
    }

    /**
     * Developer : Rakesh jha
     * Date : 03/06/2015
     * Description : Payment Control
     */
    public function paymentControlAction() {



        $payment = Admin_Model_Payment::getInstance();
        $teachingclass = Admin_Model_TeachingClasses::getInstance();
        $teachersstudents = Admin_Model_Classenroll::getInstance();
        $uservideostatus = Admin_Model_UserVideoStatus::getInstance();
        $classreviewscount = Admin_Model_ClassesReview::getInstance();
        $projects = Admin_Model_Projects::getInstance();
        $paymentdata = Admin_Model_paymentdata::getInstance();
        $objteachermonthly = Admin_Model_Teacherpaymentmonthly::getInstance();


        $result = $payment->getPaidStudents();
//        echo '<pre>';        print_r($result); die;
        $percentage = $this->getRequest()->getPost('percentage');
        $avg_nr_st = $this->getRequest()->getPost('avg_nr_st');
        $avg_nr_pr = $this->getRequest()->getPost('avg_nr_pr');
        $avg_nr_videoesviews = $this->getRequest()->getPost('avg_nr_videoesviews');
        $yearlystudentcount = 0;
        $monthlystudentcount = 0;
        $yearlyamount = 0;
        foreach ($result as $key => $value) {
            if ($value['subscription_id'] == 4 || $value['subscription_id'] == 5) {

                $yearlyamount = $value['payment_amount'];
                $yearlystudentcount++;
            }
            if ($value['subscription_id'] == 1 || $value['subscription_id'] == 3) {
                $monthlyamount = $value['payment_amount'];
                $monthlystudentcount++;
            }
        }
        $getpercentage = $paymentdata->getpercentage();
        $this->view->getpercentage = $getpercentage;

        $totalstudents = $yearlystudentcount + $monthlystudentcount;
        $this->view->monthly = $monthlystudentcount;
        $this->view->yearly = $yearlystudentcount;
//        print_r($this->view->yearly);die;
        $yearlyassets = $yearlystudentcount * $yearlyamount;


        $this->view->yearlyassets = $yearlyassets;

//        $totalstudents=  count($result); 
//        print_r($totalstudents); die;
        $this->view->totalstudents = $totalstudents;
        $monthlyassets = 40 * $monthlystudentcount;
        $this->view->monthlyassets = $monthlyassets;
//        $avergaesubscription = (($yearlyamount * $yearlystudentcount) + ($monthlyamount * $monthlystudentcount)) / $totalstudents;
        $totalassets = 35 * $totalstudents;
        $this->view->totalassets = $totalassets;
//        print_r($totalassets); 
        $payment = Admin_Model_Payment::getInstance();
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->layout()->disableLayout();
            $this->_helper->viewRenderer->setNoRender(true);
            if ($percentage) {
                $teachershare = ($totalassets * $percentage) / 100;
                $this->view->teachershare = $teachershare;
                echo $teachershare;
            }
        }
        $teachershare = ($totalassets * $getpercentage['devide_percentage']) / 100;
        $this->view->teachershare = $teachershare;


        //---------------------Show Annual Data------------------------//

        $annualadmindata = Admin_Model_AdminPaymentMonthly::getInstance();
        $annualdata = $annualadmindata->getAnnualData();
        $this->view->annualdata = $annualdata;
        $annualshare = ($yearlyassets * $getpercentage['devide_percentage']) / 100;
        $this->view->annualshare = $annualshare;

        $devidebymonthly = $yearlyassets / 12;
        $this->view->devidebymonthly = $devidebymonthly;
        $date = date("Y/m/d");
        $date = explode('/', $date);
        $year = $date[0];
        $monthdate = $date[2];
        $this->view->monthdate = $monthdate;
        $this->view->currentyear = $year;
        $currentmonth = $date[1];
        $currentmonthName = $currentmonth;
        $monthName = date('F', mktime(0, 0, 0, $currentmonthName, 10));
        $this->view->currentmonth = $monthName;


        /* ------------------Referal Teacehr Payment calculation--------------------------- */
        $users = Application_Model_Users::getInstance();

        $result = $users->getReferedStudents();

        if ($result) {
            $count = 0;
            foreach ($result as $key => $value) {
                $result1 = $users->getReferStudents();
                $monthly = $result1['monthly_user'];
                $totaluser = $value['total_user'];
                $year = ($totaluser - $monthly);
                $result[$count]['monthly_user'] = $monthly;
                $result[$count]['yearly'] = $year;
                $amount = ($year * 25 + $monthly * 10);
                $monthlyamount = ($monthly * 10);
                $yearlyamount = ($year * 25);
                $result[$count]['monthlyamount'] = $monthlyamount;
                $result[$count]['yearlyamount'] = $yearlyamount;
                $result[$count]['amount'] = $amount;
                $name = $users->getTeachername($value['user_id']);
                $result[$count]['paypal_email'] = $name['paypal_email'];
                $result[$count]['name'] = $name['first_name'];
                $count++;
            }

            $this->view->referalresult = $result;
        
            foreach ($result as $reffered) {
                $date = date("Y/m/d");
                $date = explode('/', $date);
                $year = $date[0];
                $month=$date[1];
                $monthdate = $date[2];
                if($monthdate<=15){
                    $month=$month-1;
                }
                $data = array('user_id' => $reffered['user_id'],'Year'=>$year,'month'=>$month,'date'=>$monthdate,'referalmoney' => $reffered['amount']);
                $objteachermonthly->insertmonthlyreferal($data);
            }
        
        }
        /* -----------------Teacher Salary Distribution----------------------- */

        if ($this->getRequest()->isXmlHttpRequest()) {
            $weight_average_student = $avg_nr_st;
            $weight_average_project = $avg_nr_pr;
            $weight_average_videoesvies = $avg_nr_videoesviews;
            $this->view->weight_average_student = $weight_average_student;
            if ($weight_average_student && $weight_average_project && $weight_average_videoesvies) {
                $totalweightage = $weight_average_student + $weight_average_project + $weight_average_videoesvies;
                echo $totalweightage;
            }
        }
        $teacherdetails = $teachingclass->getTeachersDetails();


        $count = 0;
        $i = 0;
        $j = 0;
        $k = 0;
        $x = 0;
        foreach ($teacherdetails as $key => $value) {

            $teacher_name = $value['first_name'];

            $teacher_id = $value['user_id'];
            $getSeenVideoCount = $uservideostatus->getSeenVideoCount($teacher_id);
            $getreviewcount = $classreviewscount->getSatisfactionPercentage($teacher_id);
            //dev: priyanka varanasi
            ////modified these line as the project count and students count giving ny the above query is wrong
            //desc: to get user projects

            $projcount = $projects->getProjectCount($value['user_id']);


            //to get user students (students enrolled)
            $studentcount = $teachersstudents->getClasEnrollCount($value['user_id']);
            if (!empty($studentcount)) {
                $teacherdetails[$count]['studentcount'] = $studentcount;
            } else {
                $teacherdetails[$count]['studentcount'] = 0;
            }
            if (!empty($projcount)) {

                $teacherdetails[$count]['projectcount'] = $projcount;
            } else {
                $teacherdetails[$count]['projectcount'] = 0;
            }
            //////////code ends///////////////////
            $teacherdetails[$count]['videoseencount'] = $getSeenVideoCount['video seen count'];
            $teacherdetails[$count]['reviewpercent'] = $getreviewcount;
            $teacherdetails[$count]['reviewpercent'] = $getreviewcount;
            $i+= $value['class count'];

            //priyanka added two lines
            $j+= $teacherdetails[$count]['projectcount'];
            $k+= $teacherdetails[$count]['studentcount'];
            //-----code ends------------//

            $x+= $teacherdetails[$count]['videoseencount'];

            $count++;
        }

        $this->view->i = $i;
        $this->view->j = $j;
        $this->view->k = $k;
        $this->view->x = $x;
        $this->view->teacherdetails = $teacherdetails;



        $nr_st = $i;

        $finalresult = array();
        $paymentuser = array();
        $countarr = 0;
        $totalpays = 0;
        $totalleftover = 0;
        foreach ($teacherdetails as $key => $value) {
 $date = date("Y/m/d");
                $date = explode('/', $date);
                $year = $date[0];
                $month=$date[1];
                $monthdate = $date[2];
                if($monthdate<=15){
                    $month=$month-1;
                }
         $referralmoney=array('month'=>$month,'Year'=>$year,'user_id'=>$value['user_id']);      
        $referalmoneyres= $objteachermonthly->teacherreferalmoney($referralmoney);
            $satisfaction_per = $value['reviewpercent'];
            if ($satisfaction_per >= 90) {
                $satisfaction_per = 100;
            } else if ($satisfaction_per >= 80) {

                $satisfaction_per = 95;
            } else if ($satisfaction_per >= 70) {
                $satisfaction_per = 90;
            } else {
                $satisfaction_per = 85;
            }
            

            $finalresult[$countarr]['first_name'] = $value['first_name'];
            $finalresult[$countarr]['user_id'] = $value['user_id'];
            $finalresult[$countarr]['payment_status'] = $value['teacher_payment_status'];
            $paymentuser[$countarr]['email'] = $value['paypal_email'];
            $finalresult[$countarr]['paypal_email'] = $value['paypal_email'];

            $finalresult[$countarr]['class count'] = $value['class count'];
            $finalresult[$countarr]['studentcount'] = $value['studentcount'];
            $finalresult[$countarr]['projectcount'] = $value['projectcount'];
            $finalresult[$countarr]['videoseencount'] = $value['videoseencount'];
            $finalresult[$countarr]['satisfaction_per'] = $value['reviewpercent'];
            @ $finalresult[$countarr]['studentcount_per'] = ($value['studentcount'] / ($j)) * $getpercentage['students_per'];
            @ $finalresult[$countarr]['projectcount_per'] = ($value['projectcount'] / ($k)) * $getpercentage['proj_per'];
            $finalresult[$countarr]['videoseencount_per'] = ($value['videoseencount'] / ($x) * $getpercentage['videoview_per']);
            $total_value = $finalresult[$countarr]['studentcount_per'] + $finalresult[$countarr]['projectcount_per'] + $finalresult[$countarr]['videoseencount_per'];
            $finalresult[$countarr]['total_value'] = $total_value;
            $finalresult[$countarr]['referalmoney'] = $referalmoneyres;
            $finalresult[$countarr]['commission_without_sat'] = (($teachershare) * $total_value) / 100;
            $finalresult[$countarr]['commission_with_sat'] = ($finalresult[$countarr]['commission_without_sat'] * $satisfaction_per) / 100;
            $paymentuser[$countarr]['amount'] = $finalresult[$countarr]['commission_with_sat'];
            $finalresult[$countarr]['left_over'] = $finalresult[$countarr]['commission_without_sat'] - $finalresult[$countarr]['commission_with_sat'];
            $totalleftover = $totalleftover + $finalresult[$countarr]['left_over'];
            $totalpays = $totalpays + $finalresult[$countarr]['commission_with_sat'];

            /*             * abhishekm
             * inserting commission of teacher in user table
             */
            $commission = Application_Model_Users::getInstance();
            $success = $commission->updatecommission($finalresult[$countarr]['commission_with_sat'], $value['user_id']);

            $countarr++;
        }
        $this->view->totalleftover = $totalleftover;
        $admindata = Admin_Model_AdminData::getInstance();
        $objteacherpaydetail = Admin_Model_Teacherpaymentdetails::getInstance();
        $data = array('studentpay' => $totalpays);
        $result = $admindata->insertAdmindata($data);
       
        foreach ($finalresult as $enrollpayment) {
                $date = date("Y/m/d");
                $date = explode('/', $date);
                $year = $date[0];
                $month=$date[1];
                $monthdate = $date[2];
                if($monthdate<=15){
                    $month=$month-1;
                }
                $data = array('teacher_id' =>$enrollpayment['user_id'],'referal_money'=>$enrollpayment['referalmoney'],'year'=>$year,'month'=>$month,'enroll_money' => $enrollpayment['commission_with_sat']);
                $objteacherpaydetail->teacehrpaymentdata($data,$month,$year);
        }
        $this->view->finalresult = $finalresult;
        
        $this->view->session->storage->paymentuser = $paymentuser;

        $users = Application_Model_Users::getInstance();
        $result = $users->getReferedStudents();
        if ($result) {
            $count = 0;
            foreach ($result as $key => $value) {
                $result1 = $users->getReferStudents();
                $monthly = $result1['monthly_user'];

                $totaluser = $value['total_user'];
                $year = ($totaluser - $monthly);
                $result[$count]['monthly_user'] = $monthly;
                $result[$count]['yearly'] = $year;
                $amount = ($year * 25 + $monthly * 10);
                $result[$count]['amount'] = $amount;
                $name = $users->getTeachername($value['user_id']);
                $result[$count]['name'] = $name['first_name'];
                $count++;
            }
            $this->view->result = $result;
        }
    }

    public function adminfinanceAction() {
        $payment = Admin_Model_Payment::getInstance();
        $teacehrdetails = Admin_Model_Teacherpaymentdetails::getInstance();
        $this->view->daysreport = $payment->getdaysstatistics();
        $this->view->weeksreport = $payment->getweekssstatistics();
        $this->view->monthsreport = $payment->getmonthsstatistics();

        $adminpaymentmonthly = Admin_Model_AdminPaymentMonthly::getInstance();
        $result = $payment->getPaidStudents();
        $toal_earned = 0;
        $teacher_share = 0;
        $yearlyleftover = 0;
        $yearly_earned = 0;
        $adminmonthlydata = $adminpaymentmonthly->getAllincome();

        $best_teacher = $teacehrdetails->bestsalarymonth();
        $worst_teacher = $teacehrdetails->worstsalarymonth();

        $this->view->best_teacher = $best_teacher['maxsalary'];
        $this->view->worst_teacher = $worst_teacher['minsalary'];

        $best_teacher_month = $best_teacher['month'];
        $best_teacher_monthanme = date('F', mktime(0, 0, 0, $best_teacher_month, 10));

        $worst_teacher_month = $worst_teacher['month'];
        $worst_teacher_month = date('F', mktime(0, 0, 0, $worst_teacher_month, 10));
        $this->view->best_teacher_month = $best_teacher_monthanme;
        $this->view->worst_teacher_month = $worst_teacher_month;
        $this->view->adminmonthlydatas = $adminmonthlydata;



        foreach ($adminmonthlydata as $value) {

            $toal_earned = $toal_earned + $value['monthly_earned'];
            $yearly_earned = $value['annual_earned'];
            $teacher_share = $teacher_share + $value['Teacher_patternship'];
        }
        $this->view->toal_earned = $toal_earned + $yearly_earned;
        $this->view->teacher_share = $teacher_share;

        $date = date("Y/m/d");
        $date = explode('/', $date);
        $year = $date[0];
        if ($date[2] >= 15) {
            $month = $date[1];
        } else {
            $month = $date[1] - 1;
        }
        $monthName = $month;
        $monthName = date('F', mktime(0, 0, 0, $monthName, 10));
        $this->view->monthname = $monthName;
        $this->view->year = $year;
        $currentmonthincome = $adminpaymentmonthly->currentmonth($month, $year);

        $currentyearincome = $adminpaymentmonthly->currentyear($month, $year);
        if (isset($currentyearincome)) {
            foreach ($currentyearincome as $value) {
                $yearlyleftover = $yearlyleftover + $value['monthlyleftover'];
            }
        }
        $this->view->yearlyleftover = $yearlyleftover;
        $monthleftover = $currentmonthincome['monthlyleftover'];
        $this->view->monthleftover = $monthleftover;
        $total_this_month = $currentmonthincome['Total'];
        $teacherpartnership = $currentmonthincome['Teacher_patternship'];
        $this->view->teacherpartnership = $teacherpartnership;
        $this->view->total_this_month = $total_this_month;
        $yearlystudentcount = 0;
        $monthlystudentcount = 0;
        $yearlyamount = 0;
        foreach ($result as $value) {



            if ($value['subscription_id'] == 4 || $value['subscription_id'] == 5) {

                $yearlyamount = $value['payment_amount'];
                $yearlystudentcount++;
            }
            if ($value['subscription_id'] == 1 || $value['subscription_id'] == 3) {
                $monthlyamount = $value['payment_amount'];
                $monthlystudentcount++;
            }
        }

        $monthlyamount = $monthlyamount * $monthlystudentcount;
        $yearlyamount = $yearlyamount * $monthlystudentcount;
        $totalamount = $monthlyamount + $yearlyamount;
        $this->view->totalamount = $totalamount;

        $totalstudents = $yearlystudentcount + $monthlystudentcount;
        $allincome = $adminpaymentmonthly->getAllincome();

        }

}
