<?php

/**
 * AdminController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Cron_CronController extends Zend_Controller_Action {

    public $teams;
    public $serachurl;
    public $teamcode;

    public function init() {
        $this->_helper->layout()->disableLayout();
        $this->_helper->viewRenderer->setNoRender(TRUE);
    }

    /**
      Developer: Namrata Singh
      Description: Cancelling subscription of users whose end date is crossed
      Date: 11 March'2015
     * */
    public function manageSubscriptionAction() {

// $currentDateTime = DATE("Y-m-d H:i:s");
//                    echo "<pre>"; print_r(strtotime($currentDateTime)); die('---');
        $objPagar = new Engine_Pagarme_PagarmeClass();
        Pagarme :: setApiKey("ak_test_te0sPIZVZ9EwuYcBdXCw5X2AoSnbad");
        //$userid = $this->view->session->storage->user_id;
        $objPayment = Application_Model_Payment::getinstance();
        $currentDateTime = DATE("Y-m-d H:i:s");
        $current_unix_timestamp = STRTOTIME($currentDateTime);
        $getPaidMember = $objPayment->selectMember();
        //echo "<pre>"; print_r($current_unix_timestamp) ; die('---current time'); 
//   echo "<pre>"; print_r($getPaidMember) ; die('hello'); 
        foreach ($getPaidMember as $val) {

            if (($current_unix_timestamp >= $val['unix_start_timestamp']) && ($current_unix_timestamp <= $val['unix_end_timestamp'])) {

                $pagarSubId = $val['pagar_subscription_id'];
                $subscription = PagarMe_Subscription :: findById($pagarSubId);
                $status = $subscription->getStatus();
                $data = array('status' => $status);
                $where = $val['payment_id'];
                $getMembers = $objPayment->updateStatus($data, $where);
            } elseif ($current_unix_timestamp > $val['unix_end_timestamp']) {

                $objPagar = new Engine_Pagarme_PagarmeClass();
                Pagarme :: setApiKey("ak_test_te0sPIZVZ9EwuYcBdXCw5X2AoSnbad");
                $subscription = PagarMe_Subscription :: findById($val['pagar_subscription_id']);
                $subscription->cancel();  // Cancel
                $status = $subscription->getStatus();

                $data = array('status' => $status);
                $where = $val['payment_id'];
                $getMembers = $objPayment->updateStatus($data, $where);
            }
        }
    }

    /**
      Developer: Namrata Singh
      Description: Giving Free month to the user who has received free months
      Date: 12 March'2015
     * */
    public function freeSubscriptionAction() {
        $objUserModel = Application_Model_Users::getinstance();
        $objPayment = Application_Model_Payment::getinstance();
        //---------------------------------
//        $count = 2;
//        $totalCountDays = $count * 30;
       // $currentDateTime = DATE("Y-m-d H:i:s");
//        // echo "<pre>"; print_r($totalCountDays); die('---');
//        $endDate = date('Y-m-d H:i:s', strtotime('+ ' . $totalCountDays . 'days'));

     //   $unixStart = STRTOTIME($currentDateTime);
//        $unixEnd = STRTOTIME($endDate);
//        echo $currentDateTime;
//        echo "<pre>";
   //     echo $unixStart;
//        echo "<pre>";
//        echo $endDate;
//        echo "<pre>";
//        echo $unixEnd;
//        echo "<pre>";
 //       die('all dates');
        //------------------------------------
        $getBonusMonths = $objUserModel->bonusMonth();
//        echo "<pre>"; print_r($getBonusMonths); die('---');
        foreach ($getBonusMonths as $bonusVal) {
            $bonusUserId = $bonusVal['user_id'];
            // echo "<pre>"; print_r($bonusVal); die('@@');
            $getLatestPayment = $objPayment->bonusFreeMonth(60);                  //gives the details of last payment made
//           echo "<pre>"; print_r($getLatestPayment); die('@#');
            if (!empty($getLatestPayment)) {

                foreach ($getLatestPayment as $latestVal) {

                    $latestStatus = $latestVal['status'];
//                 echo "<pre>"; print_r($latestStatus); die('@#');
                    if ($latestStatus == 'canceled') {
                       // die($latestStatus);
                        // echo "<pre>"; print_r($latestVal['payment_id']); die('---');
                        $count = $bonusVal['referral_counts'];

                        $totalCountDays = $count * 30;
                        $currentDateTime = DATE("Y-m-d H:i:s");
                        // echo "<pre>"; print_r($totalCountDays); die('---');
                        $endDate = date('Y-m-d H:i:s', strtotime('+ ' . $totalCountDays . 'days'));
                       
                        $unixStart = STRTOTIME($currentDateTime);
                        $unixEnd = STRTOTIME($endDate);

                        $data = array('current_period_start' => $currentDateTime,
                            'current_period_end' => $endDate,
                            'unix_start_timestamp' => $unixStart,
                            'unix_end_timestamp' => $unixEnd,
                            'status' => 'free');
                        $where = $latestVal['payment_id'];

                        $updateDetail = $objPayment->updateStatus($data, $where);              //updates status and date in payment table
                        if(isset($updateDetail) == 1){
                           
                        $dataCount = array('referral_counts' => 0);
                        $updateCount = $objUserModel->userUpdateCount($dataCount, $bonusUserId);               //updates user table with the count 0
                        
                        }
                    } else {
                       // die('outside here');
                    }
                }
            } else {
              // die('no latest payment record');
            }
        }
    }

}
