<?php
/**
 * AdminController
 *
 * @author
 * @version
 */
require_once 'Zend/Controller/Action.php';

class Static_StaticController extends Zend_Controller_Action {



    public function init() {

    }

    public function contactUsAction(){

    }
    
    
    
}
